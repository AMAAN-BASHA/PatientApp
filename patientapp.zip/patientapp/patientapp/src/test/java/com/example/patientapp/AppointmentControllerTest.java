package com.example.patientapp;


import com.example.patientapp.controller.AppointmentController;
import com.example.patientapp.entities.Appointment;
import com.example.patientapp.service.AppointmentService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class AppointmentControllerTest {

    @Mock
    private AppointmentService appointmentService;

    @InjectMocks
    private AppointmentController appointmentController;

    public AppointmentControllerTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        Appointment appointment = new Appointment();
        appointment.setAppointmentTime(LocalDateTime.now());
        appointments.add(appointment);

        when(appointmentService.findAll()).thenReturn(appointments);

        ResponseEntity<List<Appointment>> response = appointmentController.getAllAppointments();
        assertEquals(1, response.getBody().size());
    }
}
