package com.example.patientapp;


import com.example.patientapp.entities.Patient;
import com.example.patientapp.repository.PatientRepository;
import com.example.patientapp.service.PatientService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

public class PatientServiceTest {

    @Mock
    private PatientRepository patientRepository;

    @InjectMocks
    private PatientService patientService;

    public PatientServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSavePatient() {
        Patient patient = new Patient();
        patient.setName("John Doe");
        patient.setContact("123456789");

        when(patientRepository.save(patient)).thenReturn(patient);

        Patient savedPatient = patientService.save(patient);
        assertNotNull(savedPatient);
    }
}
