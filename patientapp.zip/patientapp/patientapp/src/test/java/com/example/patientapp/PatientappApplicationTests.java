package com.example.patientapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientappApplicationTests {

	@Test
	void contextLoads() {
	}

}
