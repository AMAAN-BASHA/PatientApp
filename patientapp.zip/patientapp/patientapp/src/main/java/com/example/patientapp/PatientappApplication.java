package com.example.patientapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientappApplication.class, args);
	}

}
