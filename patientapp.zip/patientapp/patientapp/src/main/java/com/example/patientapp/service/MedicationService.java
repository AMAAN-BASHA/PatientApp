package com.example.patientapp.service;


import com.example.patientapp.entities.Medication;
import com.example.patientapp.repository.MedicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicationService {
    @Autowired
    private MedicationRepository medicationRepository;

    public Medication save(Medication medication) {
        return medicationRepository.save(medication);
    }

    public List<Medication> findAll() {
        return medicationRepository.findAll();
    }

    public void deleteById(Long id) {
        medicationRepository.deleteById(id);
    }
}
